ARTICLE 4 — ALL-OPTIMAL ALIGNMENT STABILITY, 2026-11-09

This research artifact was prepared and locally verified on 2026-11-09.
Publication is recorded by the repository release page, not inferred from this
file. The older v0.3.0 tag does not contain these additions. Intended release:
https://github.com/stchigalsergey/st-functional-canonizer/releases/tag/v0.4.0
The manuscript and response are supplied separately from this data archive.

Run from this directory with Python 3.12 (standard library only):
python -X utf8 experiments/run_sensitivity.py
python -X utf8 experiments/run_external_diagnostics.py
python -X utf8 experiments/run_external_diagnostics.py --normalize-terminal-fence
python -X utf8 revision_2_3_1_2026-11-09/computational/run_review_computations.py
python -X utf8 revision_2_3_1_2026-11-09/representation/build_representation.py

Expected: synthetic188 / ambiguous34 / variable6; raw external represented11
/ ambiguous8 / variable7; separately normalized12 / ambiguous9 / variable8.
675 exhaustive oracle checks,174 matched single-output mutation cases,
9 information-loss controls,6415 occurrence records,591 traced edit operations.
Timings may vary. Do not require volatile timings or machine paths to match.

Input and output files present on packaging are pinned in SHA256SUMS.json.
Running scripts intentionally rewrites their DERIVED outputs in this copy.
Raw labels and original Excel forms remain separate and unchanged.

Annotation provenance:
initial_ai_annotation = initial AI-prepared forms, NOT independent experts.
specialist_review = separate specialist checks of those prepared forms.
agreed_review = author-confirmed agreement; actual agreement date not supplied.
representation/behavioral_records_derived = explicit static arguments and
NOT_APPLICABLE vs UNKNOWN; NOT new specialist annotations.

Coverage/interpretation:
No ST compilation, simulator execution, PLC test, classifier F1, representative
model ranking, or independent-party reproduction is asserted. New per-occurrence
source traces reproduce the existing sequence, not a complete IEC parser.

Provenance and notices:
Original computational base: https://github.com/stchigalsergey/st-functional-canonizer
v0.3.0 commit3b8069d644a188e624b72c3544c44bca999ab00a; LICENSE retained.
External inputs: selected public AutoPLC RQ1 archive and OSCAT reference material,
https://github.com/cangkui/AutoPLC; archive and per-source hashes in each record.
AutoPLC repository MIT notice retained in third_party/AutoPLC_LICENSE.txt.
Original source excerpts and embedded upstream notices are preserved. The root
license is not a claim to replace any third-party rights or notices.
