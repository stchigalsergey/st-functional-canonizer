"""Read-only representation diagnostics on public archived generation outputs.

This is a small preselected pilot, not an accuracy or model-quality benchmark.
No LLM calls or compilation/execution is performed.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
import re
from pathlib import Path
from hashlib import sha256
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'vendor_source'))
from st_canonizer_v2 import canonize
from st_defect_taxonomy import edit_script, TieBreakRule, build_error_profile
from run_sensitivity import all_optimal_bounds, dump


def analyze(path, normalize_terminal_fence=False):
    pairs = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
    normalizations = []
    if normalize_terminal_fence:
        for pair in pairs:
            if pair['pair_id'] != 'EP-D355D42F55':
                continue
            source = pair['test_source']
            assert source.count('```') == 1, 'Only the previously observed single terminal fence is eligible'
            corrected, count = re.subn(r'(?m)^[ \t]*```[ \t]*(?:\r?\n)?(?=[ \t\r\n]*\Z)', '', source, count=1)
            assert count == 1 and corrected != source
            normalizations.append({'pair_id':pair['pair_id'],'side':'test',
                                   'rule':'remove-single-standalone-terminal-markdown-fence/v1',
                                   'raw_sha256':sha256(source.encode('utf-8')).hexdigest(),
                                   'normalized_sha256':sha256(corrected.encode('utf-8')).hexdigest(),
                                   'removed_characters':len(source)-len(corrected)})
            pair['test_source'] = corrected
        assert len(normalizations) == 1
    out = []
    counts = Counter()
    groups = defaultdict(Counter)
    profiles = []
    for pair in pairs:
        result = {k: pair.get(k) for k in ('pair_id','task_id','model','provenance')}
        result['sources_sha256'] = {side: sha256(pair[side+'_source'].encode('utf-8')).hexdigest() for side in ('reference','test')}
        sequences = {}
        for side in ('reference','test'):
            try:
                seq = canonize(pair[side+'_source'], strict=True)
                sequences[side] = tuple(seq)
                result[side] = {'status':'represented','blocks':len(seq),
                                'raw_blocks':sum(s.startswith('B_RAW') for s in seq),'sequence':seq}
            except Exception as exc:
                result[side] = {'status':'analysis_failed','error_type':type(exc).__name__,'message':str(exc)}
        status = 'both_represented' if len(sequences)==2 else 'representation_failure'
        result['pair_status'] = status
        counts['pairs'] += 1; counts[status] += 1
        groups[pair['model']]['pairs'] += 1; groups[pair['model']][status] += 1
        if len(sequences)==2:
            a,b = sequences['reference'],sequences['test']
            script = edit_script(a,b,tie_break=TieBreakRule.HISTORICAL)
            bounds = all_optimal_bounds(a,b)
            result['historical'] = script.to_dict()
            result['all_optimal_bounds'] = bounds
            variable = any(lo!=hi for label,(lo,hi) in bounds['category_bounds'])
            measures = {'canonical_distance_nonzero':script.distance>0,'ambiguous_paths':script.ambiguous,
                        'category_count_variable':variable,'any_raw':result['reference']['raw_blocks']>0 or result['test']['raw_blocks']>0,
                        'empty_reference_sequence':len(a)==0,'empty_test_sequence':len(b)==0}
            for key,value in measures.items():
                counts[key] += int(value); groups[pair['model']][key] += int(value)
            profiles.append(script)
        out.append(result)
    summary = {
        'schema':'article4-public-archived-generation-diagnostics/v1','checked_on':'2026-11-09',
        'input':str(path.resolve()),'input_sha256':sha256(path.read_bytes()).hexdigest(),
        'preprocessing':'single-declared-terminal-fence-removal' if normalize_terminal_fence else 'none; raw archive-derived source text',
        'normalizations':normalizations,
        'counts':dict(counts),'by_archive_group':{k:dict(v) for k,v in sorted(groups.items())},
        'descriptive_edit_profile':build_error_profile(profiles),
        'limitations':[
            'Twelve preselected reference/output pairs, four task names and three archive model-group labels; not representative of LLMs or industrial code.',
            'The task selection is protocol-driven but small; exact model versions and original prompts/settings are not recovered.',
            'Reference and output programs have not been independently behavior-validated, compiled or executed.',
            'Reference may overlap retrieval material of the generating system; this is not a contamination-free evaluation.',
            'Analysis failure or B_RAW indicates analyzer limitations; it is not by itself evidence of a generated-program defect.',
            'A nonzero distance is a representational difference, not a verdict that the generated program is wrong.',
            'Category counts use only available structural labels; output safety is unspecified without project context.',
            'No expert-grounded functional category accuracy, precision, recall, F1, hazard detection, or model ranking is computed.'
        ]
    }
    output_name = 'external_pilot_normalized_diagnostics.json' if normalize_terminal_fence else 'external_pilot_diagnostics.json'
    dump(HERE/output_name,{'summary':summary,'pairs':out})
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pairs',type=Path,default=HERE.parent/'validation_protocol'/'external_pilot_pairs.jsonl')
    parser.add_argument('--normalize-terminal-fence', action='store_true',
                        help='Separate sensitivity pass: remove only the documented terminal fence of EP-D355D42F55')
    args=parser.parse_args()
    analyze(args.pairs, args.normalize_terminal_fence)
