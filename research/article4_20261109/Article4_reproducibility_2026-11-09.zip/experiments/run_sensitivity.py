"""Reproducible edit-kind baselines and exact all-optimal-path sensitivity.

All default data are synthetic. No LLM calls, private source, expert labels,
compiler execution, or behavioral-equivalence claims are involved.
Run: python -X utf8 run_sensitivity.py
The five unmodified public-artifact modules in vendor_source are hash pinned.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from functools import lru_cache
from hashlib import sha256
import csv
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
VENDOR = HERE / 'vendor_source'
sys.path.insert(0, str(VENDOR))

from st_article4_synthetic import generate_records, select_working_subset, summarize_records, records_jsonl
from st_canonizer import st_lex, split_unit
from st_defect_taxonomy import categorize_symbol, edit_script, matches_expected_edit_kind, TieBreakRule, build_error_profile

PINNED = {
    'st_article4_synthetic.py': '0d84b1ea5a33d8499e8b7fc072e43581193be79329176d5f8b6deec1d5c2bd3b',
    'st_canonizer.py': 'db8505940c39cbff425524fbe492e475f5d19d26878785bf9974b29bf748c14f',
    'st_canonizer_v2.py': '613763435367dc686bc6e25b061e65d1798db78e4fe8a3f8c2da284d8fb12dca',
    'st_defect_taxonomy.py': 'c3cb91150492447f54e080ce9ef9751324257f97ef428283c87c88cb27630fe6',
}


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n', encoding='utf-8', newline='\n')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def category_key(kind, reference=None, test=None):
    return (kind, categorize_symbol(reference), categorize_symbol(test))


@lru_cache(maxsize=4096)
def all_optimal_bounds(reference, test):
    """Per-label minimum/maximum count over the complete optimal-path DAG.

    A path has unit substitution/insertion/deletion costs and zero-cost equal
    matches. For each category-labelled edge and edit kind, independent
    min/max dynamic programs compute exact marginal count bounds. Bounds for
    different labels need not be jointly attainable by one path.
    """
    n, m = len(reference), len(test)
    forward = [[0] * (m + 1) for _ in range(n + 1)]
    backward = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        forward[i][0] = i
        backward[i][m] = n - i
    for j in range(m + 1):
        forward[0][j] = j
        backward[n][j] = m - j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            forward[i][j] = min(forward[i-1][j]+1, forward[i][j-1]+1,
                                forward[i-1][j-1]+(reference[i-1] != test[j-1]))
    for i in range(n-1, -1, -1):
        for j in range(m-1, -1, -1):
            backward[i][j] = min(backward[i+1][j]+1, backward[i][j+1]+1,
                                 backward[i+1][j+1]+(reference[i] != test[j]))
    distance = forward[n][m]
    edges = {}
    labels = set()
    path_count = [[0] * (m+1) for _ in range(n+1)]
    path_count[0][0] = 1
    for i in range(n+1):
        for j in range(m+1):
            if forward[i][j] + backward[i][j] != distance:
                continue
            choices = []
            if i < n and forward[i][j]+1+backward[i+1][j] == distance:
                choices.append((i+1, j, category_key('delete', reference[i], None)))
            if j < m and forward[i][j]+1+backward[i][j+1] == distance:
                choices.append((i, j+1, category_key('insert', None, test[j])))
            if i < n and j < m:
                cost = int(reference[i] != test[j])
                if forward[i][j]+cost+backward[i+1][j+1] == distance:
                    choices.append((i+1, j+1, category_key('replace', reference[i], test[j]) if cost else None))
            edges[(i,j)] = choices
            for a,b,label in choices:
                path_count[a][b] += path_count[i][j]
                if label is not None:
                    labels.add(label)

    def bounds_for(predicate):
        low = [[10**9] * (m+1) for _ in range(n+1)]
        high = [[-1] * (m+1) for _ in range(n+1)]
        low[0][0] = high[0][0] = 0
        for i in range(n+1):
            for j in range(m+1):
                if high[i][j] < 0:
                    continue
                for a,b,label in edges.get((i,j), ()):
                    add = int(label is not None and predicate(label))
                    low[a][b] = min(low[a][b], low[i][j]+add)
                    high[a][b] = max(high[a][b], high[i][j]+add)
        return [low[n][m], high[n][m]]

    category_bounds = [(label, bounds_for(lambda edge, label=label: edge == label)) for label in sorted(labels)]
    kind_bounds = {kind: bounds_for(lambda edge, kind=kind: edge[0] == kind)
                   for kind in ('delete','insert','replace')}
    return {'distance': distance, 'optimal_path_count': path_count[n][m],
            'category_bounds': category_bounds, 'kind_bounds': kind_bounds}


def brute_force_bounds(reference, test):
    """Independent exhaustive oracle for short test cases, not research data."""
    @lru_cache(None)
    def rec(i,j):
        if i == len(reference) and j == len(test):
            return 0, ((),)
        candidates = []
        if i < len(reference):
            d, tails = rec(i+1,j)
            label = category_key('delete', reference[i], None)
            candidates.extend((d+1, (label,)+tail) for tail in tails)
        if j < len(test):
            d, tails = rec(i,j+1)
            label = category_key('insert', None, test[j])
            candidates.extend((d+1, (label,)+tail) for tail in tails)
        if i < len(reference) and j < len(test):
            d, tails = rec(i+1,j+1)
            cost = int(reference[i] != test[j])
            label = category_key('replace', reference[i], test[j])
            candidates.extend((d+cost, ((label,)+tail if cost else tail)) for tail in tails)
        best = min(d for d,_ in candidates)
        return best, tuple(tail for d,tail in candidates if d == best)
    distance, scripts = rec(0,0)
    labels = set(label for script in scripts for label in script)
    intervals = {label:[min(s.count(label) for s in scripts), max(s.count(label) for s in scripts)] for label in labels}
    return distance, len(scripts), intervals


def validate_interval_dp():
    import itertools
    alphabet = ('B_FIRE_INTERLOCK', 'B_SET_OUTPUT_ON')
    sequences = [()] + [p for n in range(1,4) for p in itertools.product(alphabet, repeat=n)]
    checked = 0
    for a in sequences:
        for b in sequences:
            exact = all_optimal_bounds(a,b)
            distance, count, intervals = brute_force_bounds(a,b)
            assert exact['distance'] == distance
            assert exact['optimal_path_count'] == count
            assert dict(exact['category_bounds']) == intervals
            checked += 1
    return checked


def operation_profile(result):
    return Counter((o.kind.value, o.reference_category, o.test_category) for o in result.operations)


def expected_kind(label):
    return {'УДАЛЕНИЕ':'delete', 'ВСТАВКА':'insert', 'ЗАМЕНА':'replace', 'ПЕРЕСТАНОВКА':'move'}[label.split(':',1)[0]]


def length_baseline(a,b):
    return 'delete' if len(a)>len(b) else ('insert' if len(a)<len(b) else 'replace')


@lru_cache(maxsize=2048)
def tokens(source):
    _,body = split_unit(source)
    return tuple(t.kind+':'+t.val for t in st_lex(body, strict=True))


def main():
    source_hashes = {name:sha256((VENDOR/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest() for name in PINNED}
    assert source_hashes == PINNED, 'Vendor source differs from published v0.3 manifest'
    independent_dp_cases = validate_interval_dp()
    records, log = generate_records()
    summary = summarize_records(records, log)
    assert len(records)==282 and summary['full_corpus']['defect_variants']==990
    assert summary['full_corpus']['jsonl_sha256']=='bf92e6c383969c08f2953fc19d1a4d7143bc7eed439182ecc35a043af4ae3a43'
    selected = select_working_subset(records)
    assert len(selected)==56 and summary['working_subset']['declared_edit_kind_matches']==152
    assert summary['working_subset']['jsonl_sha256']=='3ec06d350a724134f83870e685e37d5064f6ae1bda95d91c50a9c61f051db733'
    dump(HERE/'reproduction_summary.json', summary)
    # Regenerate only this public subset, preserving the published serialization hash.
    (HERE/'public_working_subset.jsonl').write_text(records_jsonl(selected),encoding='utf-8',newline='\n')
    counts = Counter()
    by_taxonomy = defaultdict(Counter)
    hist_results, move_results = [], []
    category_aggregate = defaultdict(lambda:[0,0])
    rows = []
    outcomes = []
    true_prefixes = Counter(expected_kind(d['taxonomy']) for r in selected for d in r['defects'])
    majority_kind = true_prefixes.most_common(1)[0][0]
    for record in selected:
        ref = tuple(record['block_seq'])
        for k, defect in enumerate(record['defects'], 1):
            test = tuple(defect['block_seq'])
            label = defect['taxonomy']; kind = expected_kind(label)
            hist = edit_script(ref,test,tie_break=TieBreakRule.HISTORICAL)
            move = edit_script(ref,test,tie_break=TieBreakRule.MOVE_AWARE)
            token_hist = edit_script(tokens(record['st_code']),tokens(defect['st_code']))
            bounds = all_optimal_bounds(ref,test)
            assert hist.distance==move.distance==bounds['distance']
            assert hist.ambiguous==(bounds['optimal_path_count']>1)
            hp,mp = operation_profile(hist),operation_profile(move)
            for lab, (lo,hi) in bounds['category_bounds']:
                assert lo <= hp[lab] <= hi and lo <= mp[lab] <= hi
                category_aggregate[lab][0] += lo; category_aggregate[lab][1] += hi
            profile_variable = any(lo!=hi for _,(lo,hi) in bounds['category_bounds'])
            kind_variable = any(lo!=hi for lo,hi in bounds['kind_bounds'].values())
            may = kind!='move' and bounds['kind_bounds'][kind][1]>0
            must = kind!='move' and bounds['kind_bounds'][kind][0]>0
            hist_match=matches_expected_edit_kind(hist,label)
            move_match=matches_expected_edit_kind(move,label)
            token_match=matches_expected_edit_kind(token_hist,label)
            metrics = {
                'n': True, 'ambiguous':hist.ambiguous, 'category_count_variable':profile_variable,
                'kind_count_variable':kind_variable, 'two_rule_profile_different':hp!=mp,
                'historical_kind_presence_match':hist_match, 'forward_kind_presence_match':move_match,
                'token_kind_presence_match':token_match,
                'length_only_match':length_baseline(ref,test)==kind,
                'majority_in_sample_match':majority_kind==kind,
                'all_optimal_expected_kind_present':must,
                'some_optimal_expected_kind_present':may,
                'tie_rule_changes_expected_kind_match':hist_match!=move_match,
                'move_postprocess_match':matches_expected_edit_kind(move,label,recognize_moves=True),
            }
            counts.update({key:int(value) for key,value in metrics.items()})
            by_taxonomy[label].update({key:int(value) for key,value in metrics.items()})
            hist_results.append(hist); move_results.append(move)
            rows.append({'pair_id':record['id']+f'-D{k}', 'template':record['template'], 'taxonomy':label,
                         'expected_kind':kind, 'reference_blocks':len(ref), 'test_blocks':len(test),
                         'distance':hist.distance, 'optimal_paths':bounds['optimal_path_count'],
                         **{key:int(value) for key,value in metrics.items() if key!='n'}})
            outcomes.append({'pair_id':rows[-1]['pair_id'], 'taxonomy':label,
                             'reference_sequence':ref,'test_sequence':test,'bounds':bounds,
                             'historical':hist.to_dict(),'forward':move.to_dict()})
    assert counts['n']==188 and counts['historical_kind_presence_match']==152 and counts['ambiguous']==34
    hist_profile = build_error_profile(hist_results)
    move_profile = build_error_profile(move_results)
    total_distance = sum(r.distance for r in hist_results)
    assert total_distance==376
    agg_hist=Counter(); agg_move=Counter()
    for r in hist_results: agg_hist.update(operation_profile(r))
    for r in move_results: agg_move.update(operation_profile(r))
    intervals = [{'kind':lab[0], 'reference_category':lab[1], 'test_category':lab[2],
                  'minimum':lo,'maximum':hi,'historical_count':agg_hist[lab], 'forward_count':agg_move[lab],
                  'minimum_operation_share':lo/total_distance,'maximum_operation_share':hi/total_distance}
                 for lab,(lo,hi) in sorted(category_aggregate.items())]
    equivalent_token_changed = sum(tokens(r['st_code'])!=tokens(r['equiv']['st_code']) for r in selected)
    result = {
        'schema':'article4-strengthening/synthetic-all-optimal-v1','checked_on':'2026-11-09',
        'source_artifact_version':'0.3.0','vendor_lf_sha256':source_hashes,
        'scope':'56 synthetic references and 188 controlled synthetic mutations; no human or model accuracy claims',
        'independent_interval_dp_oracle_checks':independent_dp_cases,
        'original_workspace_source_lf_hashes_match_public_manifest': {
            name: sha256((HERE.parent.parent/'st-functional-canonizer-v0.2.0-staging'/'src'/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==expected
            for name, expected in PINNED.items()
            if (HERE.parent.parent/'st-functional-canonizer-v0.2.0-staging'/'src'/name).exists()
        },
        'working_subset_summary':dict(counts), 'by_generator_taxonomy':{k:dict(v) for k,v in sorted(by_taxonomy.items())},
        'generator_prefix_distribution':dict(true_prefixes),
        'majority_baseline_kind':majority_kind,
        'total_edit_operations':total_distance,
        'historical_profile':hist_profile,'forward_profile':move_profile,
        'aggregate_category_count_intervals':intervals,
        'equivalent_control':{'reference_pairs':len(selected),'block_nonzero_distance':0,
                              'token_nonzero_distance':equivalent_token_changed,
                              'label_origin':'generator-declared renaming/style transformations; not independently behavior-validated'},
        'limitations':[
            'Kind-presence is a set-valued diagnostic; majority and length baselines are single-label descriptive controls, not matched functional classifiers.',
            'Majority kind selected from the same sample is an in-sample descriptive reference, not a held-out learned baseline.',
            'Token comparison uses split_unit + strict st_lex; token values preserved, including identifiers and literals; no ST execution.',
            'Per-category bounds are marginal extrema. Extrema for different labels need not be jointly attained by a single edit path.',
            'All category resolution uses no project context; output categories remain OUTPUT_UNSPECIFIED. Safety is not inferred from FALSE/zero.',
            'Synthetic programs and equivalence controls inherit generator limitations; no compile or behavioral verification is asserted.',
            'The historical 156/194 combined result includes six private controlled industrial cases; only the public 152/188 component is re-run.',
            'The experiment does not validate a complete mapping of the 238 induced signatures or profiles of errors from real LLM outputs.'
        ],
    }
    dump(HERE/'sensitivity_summary.json',result)
    with (HERE/'per_pair.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    (HERE/'optimal_path_intervals.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n' for r in outcomes),encoding='utf-8',newline='\n')
    files=['public_working_subset.jsonl','reproduction_summary.json','sensitivity_summary.json','per_pair.csv','optimal_path_intervals.jsonl','run_sensitivity.py']
    files += [name for name in ['README.txt','run_external_diagnostics.py','external_pilot_diagnostics.json','external_pilot_normalized_diagnostics.json'] if (HERE/name).exists()]
    dump(HERE/'experiment_manifest.json',{'schema':'article4-strengthening-manifest/v1','files':{name:digest(HERE/name) for name in files},'vendor_lf_sha256':source_hashes})
    print(json.dumps({'counts':dict(counts),'by_taxonomy':{k:dict(v) for k,v in sorted(by_taxonomy.items())},'majority':majority_kind,
                      'equivalent_token_changed':equivalent_token_changed,'oracle_cases':independent_dp_cases,
                      'output':str(HERE/'sensitivity_summary.json')},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
