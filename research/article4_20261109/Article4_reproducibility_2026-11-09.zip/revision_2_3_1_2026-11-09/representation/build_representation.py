"""R03/R04/R05/R12 supplement. Read-only inputs; outputs stay beside this script.

Run from any directory: python -X utf8 build_representation.py
No PLC compilation or execution and no new human annotation are performed.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from pathlib import Path
from hashlib import sha256
import csv, importlib.util, itertools, json, re, shutil, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
VENDOR = ROOT / 'experiments' / 'vendor_source'
sys.path.insert(0, str(VENDOR))
import st_canonizer as sc
from st_canonizer_v2 import ParserV2, canonize
from st_defect_taxonomy import categorize_symbol, ProjectContext, edit_script


def digest(path): return sha256(Path(path).read_bytes()).hexdigest()
def dump(name, obj):
    (HERE/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def load_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text(encoding='utf-8').splitlines() if x.strip()]


def tracked_body(source):
    """Exactly split_unit's textual transformation, with original-char provenance."""
    s, origins = source, list(range(len(source)))
    patterns = [re.compile(r'\(\*.*?\*\)', re.DOTALL), re.compile(r'//[^\n]*'), sc._VAR_SECTION, sc._HDR]
    for pattern in patterns:
        parts, maps, last = [], [], 0
        for m in pattern.finditer(s):
            parts.extend((s[last:m.start()], ' '))
            maps.extend(origins[last:m.start()] + [None])
            last = m.end()
        parts.append(s[last:]); maps.extend(origins[last:])
        s, origins = ''.join(parts), maps
    assert s == sc.split_unit(source)[1]
    return s, origins


class TraceParser(ParserV2):
    def __init__(self, toks):
        super().__init__(toks); self.spans = {}; self.raw_spans = defaultdict(list)
    def parse_stmt(self):
        start = self.i
        node = super().parse_stmt()
        if node is not None: self.spans[id(node)] = (start, self.i)
        return node
    def _skip_to_semi(self):
        start = self.i
        text = super()._skip_to_semi()
        self.raw_spans[text].append((start, self.i))
        return text


def rule_for_symbol(symbol):
    prefix = symbol.split(':')[0]
    if prefix in ('B_SET_OUTPUT_OFF','B_SET_OUTPUT_ON','B_SET_OUTPUT'): return 'G02-output-unspecified'
    if prefix in ('B_FIRE_INTERLOCK','B_FROST_PROTECTION'): return 'G03-protection'
    if prefix == 'B_FEEDBACK_MONITOR': return 'G04-feedback'
    if prefix == 'B_FAULT_LATCH': return 'G05-latch'
    if prefix in ('B_TIMER','B_EDGE'): return 'G06-time-edge'
    if prefix in ('B_IF','B_LIMIT'): return 'G07-condition'
    if prefix in ('readreal','read16'): return 'G08-data-io'
    if prefix == 'word_to_byte': return 'G09-conversion'
    return 'G10-other'


def trace_source(source):
    vars_map, body = sc.split_unit(source)
    body_check, origin = tracked_body(source)
    toks = sc.st_lex(body, strict=True)
    spans = [(m.start(),m.end()) for m in sc._MASTER.finditer(body)
             if m.lastgroup not in ('WS','CBLOCK','CLINE','TYPEDPFX')]
    assert len(toks) == len(spans)
    parser = TraceParser(toks)
    stmts = parser.parse_stmt_list()
    ctx = {'type_of':lambda x: vars_map.get(x.lower(),(None,None))[1],
           'role_of':lambda x: vars_map.get(x.lower(),(None,None))[0], 'vars':vars_map}
    occurrences = []
    def getspan(node):
        if id(node) in parser.spans: return parser.spans[id(node)]
        if isinstance(node, sc.Raw) and parser.raw_spans[node.text]:
            value=parser.raw_spans[node.text].pop(0); parser.spans[id(node)]=value; return value
        return None
    def walk(nodes, ast_path):
        i=0
        while i<len(nodes):
            hit=None
            for mm in sc.MULTI_MATCHERS:
                hit=mm(nodes,i,ctx)
                if hit: recognizer=mm.__name__; break
            if hit:
                symbol,n=hit; children=[]
            else:
                symbol,children=sc.classify_single(nodes[i],ctx); n=1
                recognizer='classify_single/'+type(nodes[i]).__name__+'/'+symbol.split(':')[0]
            selected=[getspan(z) for z in nodes[i:i+n]]
            valid=[s for s in selected if s is not None]
            token_span=[min(x[0] for x in valid),max(x[1] for x in valid)] if valid else None
            if token_span:
                start,end=spans[token_span[0]][0],spans[token_span[1]-1][1]
                positions=[x for x in origin[start:end] if x is not None]
                original_span=[min(positions),max(positions)+1]
                lines=[source.count('\n',0,x)+1 for x in original_span]
                excerpt=source[original_span[0]:original_span[1]]
            else: original_span=lines=excerpt=None
            occurrences.append({'position':len(occurrences),'symbol':symbol,'category':categorize_symbol(symbol),
              'category_rule':rule_for_symbol(symbol),'project_context':None,
              'recognizer':recognizer,'ast_path':ast_path+[i],'consumed_statements':n,
              'token_range_in_transformed_body':token_span,'source_character_range':original_span,
              'source_lines_1_based':lines,'source_excerpt':excerpt,
              'meaning':'structural category; no behavioral-defect prediction'})
            for k,child in enumerate(children): walk(child,ast_path+[i,'child',k])
            i+=n
    walk(stmts,[])
    assert [x['symbol'] for x in occurrences] == canonize(source,strict=True)
    assert parser.i == len(toks)
    assert all(x['source_character_range'] is not None for x in occurrences)
    return {'sequence':[x['symbol'] for x in occurrences], 'occurrences':occurrences,
            'parser_consumed_all_tokens':True, 'raw_blocks':sum(x['symbol'].startswith('B_RAW') for x in occurrences),
            'coverage_claim':'supported extractor consumed token stream; not full ST semantic or grammatical coverage'}


def occurrence_audit():
    subset=load_jsonl(ROOT/'experiments/public_working_subset.jsonl')
    external=load_jsonl(ROOT/'validation_protocol/external_pilot_pairs.jsonl')
    rows=[]; sources=[]; rules=Counter(); categories=Counter(); modes=Counter()
    def add(pair_id,side,source,expected=None,track='synthetic',normalization='none'):
        item={'pair_id':pair_id,'side':side,'track':track,'normalization':normalization,
              'source_sha256':sha256(source.encode()).hexdigest()}
        try:
            trace=trace_source(source)
            if expected is not None: assert trace['sequence']==expected
            item.update(trace); item['status']='represented_with_RAW' if trace['raw_blocks'] else 'represented_no_RAW'
            for occ in trace['occurrences']:
                row={k:item[k] for k in ('pair_id','side','track','normalization','source_sha256')}
                row.update(occ); rows.append(row); rules[occ['category_rule']]+=1; categories[occ['category']]+=1
        except sc.UnsupportedCharacterError as e:
            item.update(status='lexical_failure',error=str(e))
        modes[(track,item['status'])]+=1; sources.append(item)
    pair_count=0
    for record in subset:
        for idx,defect in enumerate(record['defects']):
            pair_id=record['id']+'-M'+str(idx+1); pair_count+=1
            add(pair_id,'reference',record['st_code'],record['block_seq'])
            add(pair_id,'test',defect['st_code'],defect['block_seq'])
    assert pair_count==188
    for pair in external:
        for side in ('reference','test'):
            add(pair['pair_id'],side,pair[side+'_source'],track='external_raw')
    # A separately labelled normalized branch retains all twelve pairs and the one RAW block.
    for pair in external:
        for side in ('reference','test'):
            source=pair[side+'_source']; norm='none'
            if pair['pair_id']=='EP-D355D42F55' and side=='test':
                source,n=re.subn(r'(?m)^[ \t]*```[ \t]*(?:\r?\n)?(?=[ \t\r\n]*\Z)','',source,count=1)
                assert n==1; norm='remove-single-standalone-terminal-markdown-fence/v1'
            add(pair['pair_id'],side,source,track='external_normalized',normalization=norm)
    (HERE/'occurrences.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
    dump('source_representation_audit.json',sources)
    source_groups=defaultdict(dict)
    for s in sources: source_groups[(s['track'],s['pair_id'])][s['side']]=s
    operations=[]; represented_pairs=0
    for (track,pair_id),sides in source_groups.items():
        if any('sequence' not in s for s in sides.values()): continue
        represented_pairs+=1
        result=edit_script(sides['reference']['sequence'],sides['test']['sequence'])
        for index,op in enumerate(result.operations):
            record={'track':track,'pair_id':pair_id,'operation_index':index,'tie_break_id':result.tie_break_id,**op.to_dict()}
            for side,pos in [('reference',op.reference_index),('test',op.test_index)]:
                if pos is None:record[side+'_location']=None;continue
                occ=sides[side]['occurrences'][pos]
                record[side+'_location']={k:occ[k] for k in ('source_character_range','source_lines_1_based','source_excerpt','ast_path','recognizer','category_rule')}
                record[side+'_source_sha256']=sides[side]['source_sha256']
            record['parameter_status']='literal values, names and guards retained in source_excerpt; no inferred read/write, safety or execution metadata'
            record['interpretation']='one admissible optimal structural explanation; not a behavioral defect location verdict'
            operations.append(record)
    (HERE/'local_operations_with_source.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in operations),encoding='utf-8')
    result={'synthetic_pairs':pair_count,'external_pairs':len(external),'occurrences_including_repeated_reference_sides':len(rows),
            'source_status_counts':{str(k):v for k,v in modes.items()},'category_rule_counts':dict(rules),
            'category_counts':dict(categories),'unique_symbols':sorted({r['symbol'] for r in rows}),
            'all_represented_occurrences_have_original_source_spans':True,
            'local_operation_records':len(operations),'represented_pair_branches':represented_pairs,
            'scope':'Counts include references repeated per mutation and a separate normalized external branch; not independent samples.'}
    dump('occurrence_summary.json',result)
    return result


def wrap(body,decl=''):
    return 'FUNCTION_BLOCK C\nVAR_INPUT a:BOOL; b:BOOL; c:BOOL; set:BOOL; reset:BOOL; run:BOOL; fire:BOOL; temp:REAL; END_VAR\nVAR_OUTPUT Q:BOOL; END_VAR\n'+decl+'\n'+body+'\nEND_FUNCTION_BLOCK'


def load_signature_module():
    dest=HERE/'vendor_signature_induction.py'
    if not dest.exists():
        # Copy the existing published-article module, not a newly designed replacement.
        origin=ROOT.parent/'st-functional-canonizer-v0.2.0-staging/src/st_signature_induction.py'
        shutil.copyfile(origin,dest)
    license_source=ROOT.parent/'st-functional-canonizer-v0.2.0-staging/LICENSE'
    if license_source.exists(): shutil.copyfile(license_source,HERE/'LICENSE_existing_signature_module.txt')
    dump('signature_provenance.json',{'copied_module':'vendor_signature_induction.py','original_module':'st_signature_induction.py',
      'source_path':str(ROOT.parent/'st-functional-canonizer-v0.2.0-staging/src/st_signature_induction.py'),
      'sha256':digest(dest),'modified':False,'license':'MIT','copyright':'2026 Sergey Evgenievich Shchigal',
      'dependency_note':'Uses hash-pinned existing v0.3.0 parser modules for this controlled comparison; no claim to reproduce all original published article3 aggregates.'})
    spec=importlib.util.spec_from_file_location('article3_signature_existing',dest)
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    return mod


def controls():
    sig=load_signature_module()
    cases=[
      ('C01-alpha-binding',wrap('Q := a AND b;'),wrap('Q := a AND b;').replace('a:BOOL','first:BOOL').replace('b:BOOL','second:BOOL').replace('a AND b','first AND second'),'equivalent',
       'Биективное переименование входов и всех их обращений; вывод Q от переименованного окружения неизменен.'),
      ('C02-wrong-same-type-input',wrap('Q := a;'),wrap('Q := b;'),'different',
       'При a=TRUE,b=FALSE ожидается Q=TRUE, замена даёт FALSE.'),
      ('C03-independent-permutation',wrap('left := a; right := b;','VAR left:BOOL; right:BOOL; END_VAR'),wrap('right := b; left := a;','VAR left:BOOL; right:BOOL; END_VAR'),'equivalent',
       'Разные локальные цели, нет перекрёстных чтений; конечная пара(left,right)=(a,b) в обоих порядках.'),
      ('C04-priority-permutation',wrap('IF run THEN Q := TRUE; END_IF IF fire THEN Q := FALSE; END_IF'),wrap('IF fire THEN Q := FALSE; END_IF IF run THEN Q := TRUE; END_IF'),'different',
       'При run=fire=TRUE первый порядок завершает цикл Q=FALSE, второй Q=TRUE; наблюдение только в конце цикла.'),
      ('C05-reset-latch-equivalent',wrap('Q := (Q OR set) AND NOT reset;'),wrap('IF set THEN Q := TRUE; END_IF IF reset THEN Q := FALSE; END_IF'),'equivalent',
       'Сохраняющий состояние Q; последовательное выполнение, приоритет сброса; все восемь комбинаций Q,set,reset.'),
      ('C06-state-storage-loss',wrap('memory := (memory OR set) AND NOT reset; Q := memory;','VAR memory:BOOL; END_VAR'),wrap('memory := (memory OR set) AND NOT reset; Q := memory;','VAR_TEMP memory:BOOL; END_VAR'),'different',
       'В явно заданной модели persistent memory сохраняется, временная memory сбрасывается в FALSE в начале каждого вызова; после set=(TRUE,FALSE),reset=(FALSE,FALSE) итог Q=(TRUE,TRUE) против(TRUE,FALSE). Фактическая инициализация VAR_TEMP зависит от среды, поэтому это условный контроль модели.'),
      ('C07-threshold-value',wrap('IF temp > 10 THEN Q := TRUE; ELSE Q := FALSE; END_IF'),wrap('IF temp > 20 THEN Q := TRUE; ELSE Q := FALSE; END_IF'),'different',
       'Конечные REAL без NaN, temp=15: TRUE против FALSE.'),
      ('C08-expression-depth',wrap('Q := a AND (b OR c);'),wrap('Q := a AND (b AND c);'),'different',
       'a=TRUE,b=TRUE,c=FALSE: TRUE против FALSE; выявление зависит от глубины структуры выражения.'),
      ('C09-rename-domain-keyword',wrap('IF fire THEN Q := FALSE; END_IF'),wrap('IF fire THEN Q := FALSE; END_IF').replace('fire','alarm'),'equivalent',
       'Биективное переименование fire в alarm сохраняет логику, но убирает эвристику FIRE_KW. Это контрпример полной инвариантности распознавателя к именам.'),
    ]
    rows=[]
    for key,a,b,semantic,proof in cases:
        coarse=[canonize(a),canonize(b)]
        typed={str(m):[sig.signature_sequence(x,m=m) for x in (a,b)] for m in range(4)}
        def token_seq(src): return [t.kind+':'+t.val for t in sc.st_lex(sc.split_unit(src)[1])]
        row={'case_id':key,'reference_source':a,'test_source':b,'behavior_relation_in_declared_model':semantic,
             'basis':proof,'coarse_sequences':coarse,'coarse_distance':sc.block_levenshtein(*coarse),
             'typed_sequences_by_m':typed,'typed_distance_by_m':{m:sc.block_levenshtein(*v) for m,v in typed.items()},
             'literal_preserving_token_distance':sc.block_levenshtein(token_seq(a),token_seq(b)),
             'token_caveat':'Exact lexical values/names retained; declaration-only changes are not included by split_unit. Not an equivalence classifier.'}
        rows.append(row)
    # Exhaustively check finite Boolean transition models, independently of representations.
    checks={}
    alpha_pass=0
    for a,b in itertools.product((False,True),repeat=2):
        original_env={'a':a,'b':b};renamed_env={'first':a,'second':b}
        assert (original_env['a'] and original_env['b'])==(renamed_env['first'] and renamed_env['second']);alpha_pass+=1
    checks['C01-alpha-binding']={'checked':alpha_pass,'different':0}
    checks['C02-wrong-same-type-input']={'checked':4,'different':sum(a!=b for a,b in itertools.product((False,True),repeat=2))}
    independent_pass=0
    for a,b in itertools.product((False,True),repeat=2):
        first={};second={}
        first['left']=a;first['right']=b
        second['right']=b;second['left']=a
        assert first==second;independent_pass+=1
    checks['C03-independent-permutation']={'checked':independent_pass,'different':0}
    n=0
    for q,s,r in itertools.product((False,True),repeat=3):
        x=q
        if s:x=True
        if r:x=False
        assert x==((q or s) and not r);n+=1
    checks['C05-reset-latch-equivalent']={'checked':n,'different':0}
    checks['C04-priority-permutation']={'checked':8,'different':sum(((False if f else (True if r else q)) != (True if r else (False if f else q))) for q,r,f in itertools.product((False,True),repeat=3))}
    checks['C08-expression-depth']={'checked':8,'different':sum((a and (b or c)) != (a and b and c) for a,b,c in itertools.product((False,True),repeat=3))}
    state=False; preserved=[]; lost=[]
    for s in (True,False):
        state=(state or s);preserved.append(state);lost.append(s)
    assert preserved==[True,True] and lost==[True,False]
    checks['C06-state-storage-loss']={'persistent_trace':preserved,'reset_each_call_trace':lost}
    checks['C07-threshold-value']={'input':15,'reference':15>10,'test':15>20}
    dump('information_loss_controls.json',{'controls':rows,'finite_semantics_checks':checks,
      'signature_module_sha256':digest(HERE/'vendor_signature_induction.py'),
      'scope':'Existing signature module with existing CASE parser. m=0..3 only diagnostic; D_5,1 dictionary not applied. Python finite-model checks are not execution of the supplied ST by a PLC compiler.'})
    contexts={
      'missing_context':categorize_symbol('B_SET_OUTPUT_OFF'),
      'off_explicitly_safe':categorize_symbol('B_SET_OUTPUT_OFF',ProjectContext(signal_id='damper',safe_state='off',working_state='on')),
      'off_explicitly_working':categorize_symbol('B_SET_OUTPUT_OFF',ProjectContext(signal_id='damper',safe_state='on',working_state='off')),
      'explicit_override_precedence':categorize_symbol('B_SET_OUTPUT_OFF',ProjectContext(safe_state='off',category_override='DATA_IO')),
      'conflict_safe_equals_working':categorize_symbol('B_SET_OUTPUT_OFF',ProjectContext(safe_state='off',working_state='off'))}
    dump('metadata_sensitivity.json',{'results':contexts,'caveat':'Conflict safe==working is not rejected by current code: safe takes precedence. Current experiments supply no such context. Domain validation must reject inconsistent metadata before use.'})
    return rows


def behavior_records():
    source=ROOT/'validation_protocol/agreed_review_2026-11-09/agreed_labels.json'
    labels=json.loads(source.read_text(encoding='utf-8'))
    records=[]
    # All traces below refer to small explicitly declared semantic models, not a toolchain execution.
    descriptions={
      'EP-1A79F2DD28':('Наработка нарастает на один час за каждый действительный час; минимальная пауза применяется к автопрогону только если это явно принято в требовании.',
        ['Исполнимая оболочка с состоянием, сохраняемым между вызовами.','Стандартный TON: при непрерывном входе таймера TRUE после PT значение Q остаётся TRUE.','Цикл 1 с, вход программы IN=TRUE, PUMP=TRUE и RST=FALSE; управляющая ветвь сохраняет включение насоса, переполнения нет.'],
        {'PUMP':True,'timer_runtime.Q':True,'RUNTIME':1}, [{'elapsed_s':1,'RUNTIME':2},{'elapsed_s':2,'RUNTIME':3}],
        'IF timer_runtime.Q увеличивает RUNTIME на 1 в каждом цикле. За две секунды получается +2 часа. Для MIN_OFFTIME: при RUN_EVERY=1 s,MIN_OFFTIME=10 s,после 1 s timer_auto.Q=TRUE,timer_off.Q=FALSE автопрогон всё равно ставит PUMP=TRUE; вывод условен применимостью минимальной паузы к автопрогону.'),
      'EP-1F29CB93CF':('В среднем диапазоне IN должен влиять на длительность включённой части импульсного цикла.',
        ['CYCLE_TIME>0, стандартный TON с ET=PT при Q=TRUE.','TIME трактуется в одной числовой единице, арифметика без переполнения.','TEST=FALSE; ARE=FALSE; cycle_counter=0; IN=128,SENS=10.'],
        {'OUT':False,'timer.Q':False},[{'event':'timer reaches PT','ET_over_PT':1,'predicate':'128 > 255','predicate_value':False,'OUT':False}],
        'OUT обновляется только при timer.Q=TRUE. Тогда (timer.ET*255)/CYCLE_TIME=255 и условие IN>255 ложно для любого BYTE. Между этими событиями OUT сохраняется. Начав с FALSE, выход не формирует нужную включённую часть цикла. TEST дополнительно просто переключает OUT каждый вызов; приоритет TEST/ARX без требования не классифицирован.'),
      'EP-2A4ADDBD85':('Шина ARX должна освобождаться после завершения автопрогона, чтобы разрешать другим модулям работу.',
        ['ARE=TRUE, ARX=FALSE изначально.','SELF_ACT_TIME>0, timerSelfAct первоначально сброшен, первый вызов не завершает выдержку.','Нет внешних записей ARX; последовательные вызовы с сохранением состояния.'],
        {'ARX':False,'timerSelfAct.Q':False,'cycleCounter':0},[{'scan':1,'ARX':True,'timerSelfAct.Q':False},{'scan':2,'outer_guard':False,'ARX':True},{'scan':'all later','outer_guard':False,'ARX':True}],
        'Первый вход присваивает ARX=TRUE; выход таймера ещё FALSE. Во всех следующих циклах IF ARE AND NOT ARX ложно. Ни повторный вызов таймера, ни вложенное присваивание ARX=FALSE недостижимы. Индукцией ARX остаётся TRUE. При SELF_ACT_TIME=0 это доказательство не применимо.'),
      'EP-3011145D5A':('Модуль не должен снимать признак занятой общей шины ARX, установленный другим участником.',
        ['ARX разделяется между модулями; другой участник записал TRUE.','Текущий участник не владеет шиной; TEST=FALSE.'],
        {'ARX':True,'TEST':False,'ARE':True},[{'scan':1,'branch':'ELSE','ARX':False,'ARO':False}],
        'Первый IF TEST AND ARE выполняет ELSE и записывает ARX=FALSE независимо от владельца. Это один конфликт общей шины, допускающий две метки DATA_IO и INTERLOCK, а не два независимых дефекта.'),
      'EP-53F9B5D695':('Насос должен сохранять включённое состояние как минимум MIN_ONTIME, даже при раннем снятии IN.',
        ['Исполнимая оболочка, CURRENT_TIME монотонен, сохраняемое состояние.','MIN_ONTIME=10 s, RUN_EVERY=0,MANUAL=FALSE.'],
        {'is_running':True,'PUMP':True,'last_on_time_s':0},[{'current_time_s':1,'IN':False,'stop_guard':True,'PUMP':False}],
        'Условие остановки содержит OR NOT IN: оно истинно через одну секунду при снятии IN, хотя 1<10. Отдельный вывод TYPE_CONVERSION условен единицей TIME_TO_REAL: при миллисекундах деление на3600 даёт ошибку масштаба1000; это не универсальный факт о неизвестной среде.'),
      'EP-D355D42F55':('При непрерывном IN насос остаётся включённым после минимального времени; RUN_EVERY=0 отключает автопрогон.',
        ['Исполнимая оболочка и монотонное GET_TIME в одной единице; состояние сохраняется.','Для контрпримера остановки: MIN_ONTIME=10 s,IN=TRUE,MANUAL=FALSE,RST=FALSE,RUN_EVERY=1 h.','Авторский текст включает неподдержанный фрагмент .TOD, его исполнимость здесь не утверждается.'],
        {'pump_active':True,'last_on_time_s':0},[{'current_time_s':10,'IN':True,'pump_active':False,'PUMP':False}],
        'После достижения MIN_ONTIME второй IF снимает pump_active даже при IN=TRUE; RUN_EVERY=1 h исключает повторный автозапуск в этом цикле. Независимый условный автопрогон: при RUN_EVERY=0 и 0<=elapsed<MIN_OFFTIME нижняя ветка всё равно включает внутренний pump_active. Это присваивание не изменяет PUMP текущего цикла, присвоенный раньше; влияние на следующий цикл зависит от верхних ветвей. В частности, при IN=FALSE и MANUAL=FALSE верхний ELSE может снова снять pump_active до присваивания PUMP. .TOD и деление на3600 требуют проверки среды, не заменяют этот логический контрпример.'),
      'EP-704FE863EB':('Внутри полосы гистерезиса Q сохраняет предыдущее состояние; WIN истинен внутри полосы.',
        ['Конечные REAL,ON=10,OFF=0, границы WIN включены.','Состояние Q=TRUE установлено предшествующим IN>10.'],
        {'Q':True},[{'IN':5,'expected_Q':True,'actual_Q':False,'expected_WIN':True,'actual_WIN':False}],
        'Q присваивается (IN>ON), что даёт FALSE при5. Одновременно (IN>=ON AND IN<=OFF) невозможно приON>OFF. Обе ошибки подтверждены подстановкой в исходные выражения.'),
      'EP-7DE09A5D68':('WIN включает границы полосы и работает при прямом и обратном расположении порогов.',
        ['Конечные REAL,ON≠OFF; границы WIN включены.'],
        {},[{'ON':10,'OFF':0,'IN':0,'expected_WIN':True,'actual_WIN':False},{'ON':0,'OFF':10,'IN':5,'expected_WIN':True,'actual_WIN':False}],
        'В первом случае строгий IN>OFF отвергает нижнюю границу; во втором единая формула IN>OFF AND IN<ON ложна внутри обратной полосы. Сохранение Q через prevQ не исправляет WIN.'),
    }
    for r in labels:
        item=dict(r); item['original_severity']=item['severity'];item['severity']='NOT_APPLICABLE' if item['behavior_status']=='CORRECT' else item['severity']
        item['derived_by']='assistant static reconstruction from original source and agreed labels; not additional specialist annotation'
        packet=ROOT/'validation_protocol/review_packets'/f"{r['case_id']}.txt"
        item['source_packet_sha256']=digest(packet)
        if r['case_id'] in descriptions:
            req,assumptions,initial,inputs,proof=descriptions[r['case_id']]
            item.update(requirement=req,assumptions=assumptions,initial_state=initial,input_and_observation_trace=inputs,manual_proof=proof)
        elif r['case_id'] in ('EP-02FA9B9857','EP-D074737CF3'):
            item.update(requirement='FF_RSE: установка по фронту CS, сброс по фронту CR, приоритет сброса при одновременных фронтах и RST.',assumptions=['Q,last_CS,last_CR сохраняются между вызовами; начальное состояние соответствует одному экземпляру.','Входы CS,CR,RST фиксированы в течение вызова; выход наблюдается после всех инструкций. Реакция между вызовами не рассматривается.'],initial_state='Произвольные BOOL Q,last_CS,last_CR; при запуске конкретного экземпляра last_CS=last_CR=FALSE по объявлениям.',input_and_observation_trace='64 комбинации Q,last_CS,last_CR,CS,CR,RST для каждой из двух реализаций.',manual_proof='Положим S=CS AND NOT last_CS и R=RST OR (CR AND NOT last_CR). В обеих реализациях Qnext=(Q OR S) AND NOT R, last_CSnext=CS,last_CRnext=CR. При RST=TRUE внешний IF даёт FALSE; иначе IF установки выполняется перед IF сброса. В EP-D074737CF3 дополнительный IF одновременных фронтов повторяет уже полученный FALSE. Полный перебор64 комбинаций для каждой реализации подтвердил равенство тройки состояний этой функции перехода. По индукции переходы совпадают для любой конечной последовательности входов при одинаковом начальном состоянии.')
        elif r['case_id']=='EP-91C304F293':
            item.update(requirement='HYST с включёнными границамиWIN',assumptions=['Конечные REAL;ON≠OFF; состояниеQ сохраняется между циклами.'],initial_state='Q произвольный BOOL',input_and_observation_trace='Разбиение IN на <min,=min,между,=max,>max для обоих порядков ON/OFF.',manual_proof='ДляON>OFF ветви устанавливаютQ только за порогами; в полосе присваивания нет и состояние сохраняется. ДляON<OFF симметрично. WIN выражается включённым интервалом в обоих порядках. Равенство порогов иNaN вне утверждения.')
        else:
            item.update(requirement='Reset-priority latch in integration context',assumptions=['Нужны полный FB, схема вызова FB_BODY и инициализации.'],initial_state='UNKNOWN',input_and_observation_trace=[],manual_proof='Недостаточно контекста для доказательства; статус UNCERTAIN сохранён.')
        item['execution_status']='MANUAL_SMALL_MODEL_ARGUMENT; NOT_COMPILED; NO_PLC_EXECUTION'
        records.append(item)
    dump('behavioral_records_derived.json',{'source_sha256':digest(source),'records':records,
      'severity_note':'NOT_APPLICABLE replaces UNKNOWN only for three CORRECT cases in this derived schema. One UNCERTAIN remains UNKNOWN. Eight MEDIUM labels are historical specialist-agreed functional labels, not validated process-risk levels.'})
    with (HERE/'behavioral_records_derived.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fields=list(dict.fromkeys(k for r in records for k in r))
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        writer.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in records)
    # Independently executable arithmetic/Boolean checks supporting the supplied concrete traces.
    tests=[]
    runtime=1
    for _ in range(2): runtime+=1
    assert runtime==3;tests.append('EP-1A79F2DD28 runtime increment')
    assert not (128>1*255);tests.append('EP-1F29CB93CF TON.Q predicate')
    arx=False;trace=[]
    for scan in range(5):
        if not arx: arx=True  # initially Q=False, hence no reset branch
        trace.append(arx)
    assert all(trace);tests.append('EP-2A4ADDBD85 guarded ARX invariant')
    arx=True
    if False and True: arx=True
    else: arx=False
    assert not arx;tests.append('EP-3011145D5A shared-bus overwrite')
    assert (1>=10 or not False);tests.append('EP-53F9B5D695 premature stop')
    assert 10>=10;assert 0>=0 and 0<10;tests.append('EP-D355D42F55 stop and disabled autorun')
    assert not (5>10);assert not (5>=10 and 5<=0);tests.append('EP-704FE863EB interior memory and WIN')
    assert not (0>0 and 0<10);assert not (5>10 and 5<0);tests.append('EP-7DE09A5D68 boundary and reversed WIN')
    ff_checks={}
    for case_id in ('EP-02FA9B9857','EP-D074737CF3'):
        n=0
        for q,old_cs,old_cr,cs,cr,rst in itertools.product((False,True),repeat=6):
            s=cs and not old_cs;r=rst or (cr and not old_cr)
            expected=((q or s) and not r,cs,cr)
            actual=q
            if rst:actual=False
            else:
                if cs and not old_cs:actual=True
                if cr and not old_cr:actual=False
                if case_id=='EP-D074737CF3' and s and (cr and not old_cr):actual=False
            assert (actual,cs,cr)==expected;n+=1
        ff_checks[case_id]={'checked':n,'different':0}
    # HYST is piecewise constant on the five regions for each distinct threshold order.
    hyst_checked=0
    for on,off in ((10,0),(0,10)):
        for x in (-1,0,5,10,11):
            for q in (False,True):
                actual=q
                if on>off:
                    if x>on:actual=True
                    elif x<off:actual=False
                    win=off<=x<=on
                else:
                    if x<on:actual=True
                    elif x>off:actual=False
                    win=on<=x<=off
                target=q if min(on,off)<=x<=max(on,off) else (x>on if on>off else x<on)
                assert actual==target and win==(min(on,off)<=x<=max(on,off));hyst_checked+=1
    dump('behavioral_arithmetic_checks.json',{'passed':tests,'FF_RSE_transition_checks':ff_checks,
      'HYST_partition_checks':{'checked':hyst_checked,'different':0},
      'scope':'Small expressions and transition models, not interpretation or execution of entire ST files.'})


def report(summary,rows):
    rules=[
      {'id':'G01-context-override','priority':0,'input':'любое вхождение + category_override','output':'явная категория','active_in_current_data':False,'conflict':'перекрывает все эвристики; корректность внешних метаданных не проверяется'},
      {'id':'G02-output-unspecified','priority':1,'input':'B_SET_OUTPUT_OFF/ON/SET','output':'OUTPUT_UNSPECIFIED без проектного контекста','active_in_current_data':True,'positive_example':'Q:=FALSE -> B_SET_OUTPUT_OFF','conflict':'FALSE/0 не доказывает безопасность; safe проверяется раньше working; противоречивые metadata должны отвергаться внешней проверкой'},
      {'id':'G03-protection','priority':2,'input':'B_FIRE_INTERLOCK/B_FROST_PROTECTION','output':'PROTECTION_INTERLOCK','active_in_current_data':True,'positive_example':'IF fire THEN...','conflict':'только лексическая эвристика FIRE_KW/FROST_KW; fire имеет приоритет; переименование может менять метку, а похожее имя давать ложную доменную интерпретацию'},
      {'id':'G04-feedback','priority':2,'input':'B_FEEDBACK_MONITOR','output':'FEEDBACK_MONITOR','active_in_current_data':True,'positive_example':'TON-вызов + следующий IF с timer.Q','conflict':'распознаватель не доказывает, что это аварийный контроль обратной связи; тело IF поглощается целиком'},
      {'id':'G05-latch','priority':2,'input':'B_FAULT_LATCH','output':'FAULT_LATCH_RESET','active_in_current_data':True,'positive_example':'Q:=(Q OR set) AND NOT reset','conflict':'память функционального состояния не обязательно память аварии; два IF распознаются по форме присваиваний, без доказательства значения условий'},
      {'id':'G06-time-edge','priority':2,'input':'B_TIMER/B_EDGE','output':'TIMER_EDGE','active_in_current_data':True,'positive_example':'ton(IN:=...); rt(CLK:=...)','conflict':'тип TON/TOF/TP,R_TRIG/F_TRIG или эвристика имени; параметры и вызовы разных однотипных экземпляров в B_* неразличимы'},
      {'id':'G07-condition','priority':2,'input':'B_IF/B_LIMIT','output':'CONDITION_RANGE_CHECK','active_in_current_data':True,'positive_example':'IF temp>10 THEN...; x:=LIMIT(...)','conflict':'наличие проверки; не подтверждённое нарушение CONDITION_RANGE из экспертных форм'},
      {'id':'G08-data-io','priority':2,'input':'readreal/read16','output':'DATA_IO','active_in_current_data':False,'positive_example':'префикс сигнатуры readreal','conflict':'не встречается среди символов текущего B_*; не включать в фактическое покрытие'},
      {'id':'G09-conversion','priority':2,'input':'word_to_byte','output':'TYPE_CONVERSION','active_in_current_data':False,'positive_example':'префикс word_to_byte','conflict':'не встречается среди символов текущего B_*'},
      {'id':'G10-other','priority':3,'input':'остальные,включая B_RAW','output':'OTHER','active_in_current_data':True,'positive_example':'B_ASSIGN,B_FBCALL,B_LOOP,B_CASE,B_MODE_FSM,B_RAW:hash','conflict':'OTHER — отказ от более узкой категории; RAW отдельно означает неполный разбор, а не произвольную корректную конструкцию'},
    ]
    dump('category_rules.json',{'schema':'actual-prefix-gamma-audit/v1','rules':rules,'per_occurrence':'occurrences.jsonl',
      'validation_boundary':'Rule-execution consistency and observed prefix coverage only, not independent human validation of engineering labels. Full historical dictionary of238symbols is not mapped or validated here.'})
    passport={
      'main_representation':'manual-block-prefix/v0.3.0; CASE parserv2; strict lexing',
      'historical_990':'282 parameterizations of16templates; historical data, not new independent cases',
      'synthetic_188':'56 selected references with188mutations; actual per-occurrence source spans supplied',
      'external_12':'4task names x3archive groups; strict source branch23/24individual sources represented (11/12 completepairs); separately normalized24/24 with1RAW',
      'signature_sensitivity':'existing article3-typed-signature-v1; m=0,1,2,3; no trained D_5,1 codebook, signature equality only',
      'historical_D5_1':'238 corpus-induced symbols; not the representation used for the188pairs or AutoPLC category profiles',
      'grammatical_scope':['Assignments; calls with positional/named arguments; IF/ELSIF/ELSE; CASEv2 numeric/enumerated label lookahead; FOR/WHILE/REPEAT bodies; RETURN/EXIT/CONTINUE.','Declarations by regular expressions; no full scope/type/symbol resolution. Complex declaration forms may be missed.','Loop headers/REPEAT condition and array-index expressions discarded; typed numeric literal prefixes removed during lexing.','Parser syntax recovery preserves Raw text as24-bit SHA1 prefix, not the original text in the sequence; supplement retains exact original excerpt. Hash collision freedom not proved.'],
      'traversal':'source-order preorder: node then branch bodies; multi-matchers first (two-IF latch, then timer+IF), consume matched statement groups without recursive child emission; afterward single-statement recognizer',
      'single_rule_precedence':'Assign:latch, LIMIT, output heuristic, ordinary assign. Call:timer,edge,LIMIT,generic. IF:fire,frost,generic. CASE:mode-name heuristic,generic. Loop/simple/RAW/fallback.',
      'literal_identity':'Manual B_* does not preserve general variable binding or literal values; outputzero/nonzero discrimination remains. Typed signatures preserve role/type, fieldtail, literalclasses(BT/BF,N0/N,T,S), not same-role/type variable identity or nonzero literalvalues.',
      'coordinates':'Original API returns strings without coordinates. New audit wrapper reconstructs exact original character and line spans for every emitted occurrence and asserts identical sequences; raw texts/hashes retained. Token ranges refer to transformedbody. Ranges may overlap for parent/childnodes.',
      'coverage':'Token-consumption, RAW count and extraction failure are separate statuses. Even noRAW and consumedtokenstream do not prove full IEC grammar or semantic coverage.',
      'category_boundary':'One structural category per occurrence from prefix table without domain metadata; behavior categories supplied by specialists refer to programs/requirements. No automatic mapping to defect predictions is established.',
      'files_sha256':{p.name:digest(p) for p in VENDOR.glob('*.py')},
    }
    dump('experiment_passport.json',passport)
    lines=['ДОПОЛНЕНИЕ R03/R04/R05/R12, 09.11.2026','',
      'Команда: python -X utf8 build_representation.py',
      'Исходные данные и оценки не изменены. Дополнение не является новой независимой экспертизой или испытанием ПЛК.',
      '',f"188 синтетических пар; 12 внешних пар в двух явно разделённых ветках. Всего строк вхождений с повторами эталонов: {summary['occurrences_including_repeated_reference_sides']}.",
      'Каждое представленное вхождение снабжено правилом, категорией, AST-путём и координатами/фрагментом исходного текста. Последовательность трассировки проверена на равенство существующему canonize.',
      f"R15: {summary['local_operation_records']} локальных операций для {summary['represented_pair_branches']} обработанных веток пар связаны с координатами и исходными фрагментами. Literal/name/guard доступны в исходном фрагменте; новые выводы о read/write или безопасности не приписываются.",
      '', 'Измеренные контроли (B_* / typed m=0,1,2,3 / literal-preserving lexical):']
    for r in rows: lines.append(f"{r['case_id']}: {r['behavior_relation_in_declared_model']}; {r['coarse_distance']} / {list(r['typed_distance_by_m'].values())} / {r['literal_preserving_token_distance']}. {r['basis']}")
    lines+=['','Главные выводы для статьи:',
      '1. Структурный ноль может скрывать замену однотипного входа, изменение порога и потерю состояния. Повышение глубины выражения не восстанавливает потерянную идентичность переменной/значение литерала/класс хранения.',
      '2. Блоки B_* распознаются по ограниченным формальным и именовым эвристикам. Условное название PROTECTION_INTERLOCK не является доказательством инженерного назначения; OTHER явно сохраняется.',
      '3. Безусловную инвариантность к переименованию заявлять нельзя: fire->alarm меняет доменный символ, хотя булева функция неизменна.',
      '4. Типизированная сигнатура m=0..3 — отдельный диагностический контроль, не изменение основного эксперимента188/12 и не переклассификация238 исторических символов.',
      '5. Статусы DEFECTIVE сопровождаются доказательствами малых условных моделей в behavioral_records_derived.json. ТриCORRECT имеют severity NOT_APPLICABLE; одинUNCERTAIN UNKNOWN. MEDIUM оставлен вспомогательным историческим атрибутом без модели риска.',
      '6. Цифры покрытия относятся к извлечению. Нет ST-компиляции, симуляции, физического ПЛК, новых человеческих оценок или установленной точности инженерной классификации.',
      '', 'Готовность замечаний: R03/R04 — спецификация и полная трассировка используемого подмножества; независимая инженерная валидность правил не установлена. R05 — девять воспроизводимых парных контролей, включая явные потери. R12 — условные доказательства ключевых случаев и разведение N/A/UNKNOWN; полная среда исполнения архивных ответов по-прежнему неизвестна.']
    (HERE/'REPORT_R03_R04_R05_R12.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')


if __name__=='__main__':
    summary=occurrence_audit()
    control_rows=controls()
    behavior_records()
    report(summary,control_rows)
    print(json.dumps({'summary':summary,'controls':[{k:r[k] for k in ('case_id','coarse_distance','typed_distance_by_m','literal_preserving_token_distance')} for r in control_rows]},ensure_ascii=False,indent=2))
