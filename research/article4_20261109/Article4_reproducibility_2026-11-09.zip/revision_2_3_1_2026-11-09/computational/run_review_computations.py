"""Article 4 revision: exact contextual profile bounds, audit and experiments.

Run from any directory: python -X utf8 run_review_computations.py
Inputs are read-only files in ../../experiments and ../../validation_protocol.
No PLC execution, model calls, publication or human annotation is performed.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from functools import lru_cache
from itertools import product, permutations
from pathlib import Path
from hashlib import sha256
import csv
import gc
import json
import platform
import statistics
import sys
import time
import tracemalloc

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
EXPERIMENTS = ROOT / 'experiments'
sys.path.insert(0, str(EXPERIMENTS))
sys.path.insert(0, str(EXPERIMENTS / 'vendor_source'))
from st_canonizer_v2 import canonize
from st_defect_taxonomy import categorize_symbol, edit_script
from st_article4_synthetic import generate_records, select_working_subset
from run_sensitivity import tokens, expected_kind, length_baseline

EMPTY = '∅'
KINDS = ('replace', 'delete', 'insert')
PRIORITIES = tuple(permutations(('diagonal', 'delete', 'insert')))


def write_json(name, obj):
    (HERE / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')


def write_csv(name, rows):
    with (HERE / name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def label_text(label):
    return '|'.join(label)


def distances(x, y, reverse=False):
    """Full unit-cost prefix distance matrix. Reversal yields suffix matrix."""
    if reverse:
        x, y = x[::-1], y[::-1]
    m, n = len(x), len(y)
    d = [[0]*(n+1) for _ in range(m+1)]
    for i in range(m+1):
        d[i][0] = i
    for j in range(n+1):
        d[0][j] = j
    for i in range(1, m+1):
        for j in range(1, n+1):
            d[i][j] = min(d[i-1][j]+1, d[i][j-1]+1, d[i-1][j-1]+int(x[i-1]!=y[j-1]))
    return [[d[m-i][n-j] for j in range(n+1)] for i in range(m+1)] if reverse else d


def optimal_graph(x, y, cx=None, cy=None, forward=None):
    """DAG includes exactly edges lying on some optimal complete path.

    Categories are fixed on occurrences before alignment and need not be
    functions of the symbols. Equality/cost uses symbols only. Matching two
    equal symbols carries no edit label even when their context tags differ.
    """
    x, y = tuple(x), tuple(y)
    cx = tuple(map(categorize_symbol, x)) if cx is None else tuple(cx)
    cy = tuple(map(categorize_symbol, y)) if cy is None else tuple(cy)
    assert len(cx)==len(x) and len(cy)==len(y)
    m, n = len(x), len(y)
    f = distances(x, y) if forward is None else forward
    r = distances(x, y, reverse=True)
    best = f[m][n]
    edges = {}
    labels = set()
    counts = {(0,0): 1}
    # Lexicographic (i,j) is topological: every edge increases i or j.
    for i in range(m+1):
        for j in range(n+1):
            if f[i][j]+r[i][j] != best:
                continue
            choices = []
            candidates = []
            if i<m:
                candidates.append(((i+1,j),1,'delete',('delete',cx[i],EMPTY)))
            if j<n:
                candidates.append(((i,j+1),1,'insert',('insert',EMPTY,cy[j])))
            if i<m and j<n:
                cost = int(x[i]!=y[j])
                candidates.append(((i+1,j+1),cost,'diagonal',('replace',cx[i],cy[j]) if cost else None))
            for dest,cost,kind,label in candidates:
                a,b = dest
                if f[i][j]+cost+r[a][b] == best:
                    assert f[a][b] == f[i][j]+cost
                    edge = ((i,j),dest,cost,kind,label)
                    choices.append(edge)
                    counts[dest] = min(2, counts.get(dest,0)+counts.get((i,j),0))
                    if label is not None:
                        labels.add(label)
            edges[(i,j)] = choices
    return {'x':x, 'y':y, 'cx':cx, 'cy':cy, 'distance':best, 'f':f, 'r':r,
            'edges':edges, 'labels':sorted(labels), 'end':(m,n), 'paths_capped':counts[(m,n)]}


def extremum(graph, label, maximize=False, witness=False):
    """One label at a time: O(|V*|+|E*|) working entries."""
    values = {(0,0):0}
    parent = {} if witness else None
    for u, edges in graph['edges'].items():
        if u not in values:
            continue
        for edge in edges:
            _,v,_,_,tag = edge
            candidate = values[u]+int(tag==label)
            if v not in values or (candidate>values[v] if maximize else candidate<values[v]):
                values[v] = candidate
                if witness:
                    parent[v] = edge
    result = values[graph['end']]
    if not witness:
        return result
    path = []
    u = graph['end']
    while u != (0,0):
        edge = parent[u]
        path.append(edge)
        u = edge[0]
    path.reverse()
    assert sum(e[2] for e in path)==graph['distance']
    assert sum(e[4]==label for e in path)==result
    return result,path


def bounds(graph):
    return {label:(extremum(graph,label),extremum(graph,label,True)) for label in graph['labels']}


def select_path(graph, priorities=('diagonal','delete','insert')):
    rank = {kind:i for i,kind in enumerate(priorities)}
    u = (0,0)
    result = []
    while u != graph['end']:
        edge = min(graph['edges'][u],key=lambda e:rank[e[3]])
        result.append(edge)
        u = edge[1]
    assert sum(e[2] for e in result)==graph['distance']
    return result


def profile(path):
    return Counter(e[4] for e in path if e[4] is not None)


def path_json(graph, path):
    out = []
    for u,v,cost,kind,label in path:
        i,j = u
        out.append({'from':u,'to':v,'cost':cost,'operation':('replace' if kind=='diagonal' else kind) if cost else 'match',
                    'label':label,'reference_index':i if v[0]>i else None,
                    'test_index':j if v[1]>j else None,
                    'reference_symbol':graph['x'][i] if v[0]>i else None,
                    'test_symbol':graph['y'][j] if v[1]>j else None})
    return out


def exhaustive_oracle(x,y,cx,cy):
    """Enumerate ALL lattice paths, then select the optimum (short cases only).

    Does not call graph builder, distance recurrence, or extremum recurrence.
    """
    all_paths = []
    def visit(i,j,cost,labels):
        if i==len(x) and j==len(y):
            all_paths.append((cost,tuple(labels)))
            return
        if i<len(x):
            visit(i+1,j,cost+1,labels+[('delete',cx[i],EMPTY)])
        if j<len(y):
            visit(i,j+1,cost+1,labels+[('insert',EMPTY,cy[j])])
        if i<len(x) and j<len(y):
            different=x[i]!=y[j]
            visit(i+1,j+1,cost+int(different),labels+([('replace',cx[i],cy[j])] if different else []))
    visit(0,0,0,[])
    best=min(c for c,_ in all_paths)
    paths=[p for c,p in all_paths if c==best]
    all_labels=sorted(set(t for p in paths for t in p))
    oracle={tag:(min(p.count(tag) for p in paths),max(p.count(tag) for p in paths)) for tag in all_labels}
    return best,paths,oracle


def validate():
    seqs=[()] + [p for n in range(1,4) for p in product(('a','b'),repeat=n)]
    records=[]
    for mode in ('symbol','position','side_and_position'):
        for x in seqs:
            for y in seqs:
                if mode=='symbol':
                    cx=tuple(s.upper() for s in x); cy=tuple(s.upper() for s in y)
                elif mode=='position':
                    cx=tuple('AB'[i%2] for i in range(len(x))); cy=tuple('AB'[i%2] for i in range(len(y)))
                else:
                    cx=tuple('AB'[i%2] for i in range(len(x))); cy=tuple('BA'[i%2] for i in range(len(y)))
                oracle_d,paths,oracle_bounds=exhaustive_oracle(x,y,cx,cy)
                g=optimal_graph(x,y,cx,cy); b=bounds(g)
                assert g['distance']==oracle_d and g['paths_capped']==min(2,len(paths)) and b==oracle_bounds
                for tag,(low,high) in b.items():
                    assert extremum(g,tag,witness=True)[0]==low
                    assert extremum(g,tag,True,True)[0]==high
                for priorities in PRIORITIES:
                    pp=profile(select_path(g,priorities))
                    assert all(low<=pp[tag]<=high for tag,(low,high) in b.items())
                assert extremum(g,('ABSENT','X','Y'))==extremum(g,('ABSENT','X','Y'),True)==0
                records.append({'mode':mode,'x':x,'y':y,'cx':cx,'cy':cy,'distance':oracle_d,'optimal_paths':len(paths),'bounds':[(tag,values) for tag,values in b.items()]})
    # Aggregate bounds: independent choice of one path per comparison.
    a=exhaustive_oracle(('a','b'),('b','a'),('A','B'),('B','A'))
    b=exhaustive_oracle(('a','a'),('a',),('A','B'),('A',))
    union=set(a[2])|set(b[2])
    for tag in union:
        sums=[pa.count(tag)+pb.count(tag) for pa,pb in product(a[1],b[1])]
        assert min(sums)==a[2].get(tag,(0,0))[0]+b[2].get(tag,(0,0))[0]
        assert max(sums)==a[2].get(tag,(0,0))[1]+b[2].get(tag,(0,0))[1]
    write_json('oracle_checks.json',{'alphabet':['a','b'],'lengths':[0,1,2,3],
               'sequences_per_side':15,'pairs_per_context_rule':225,'context_rules':3,
               'checked_pairs':len(records),'enumerator':'all legal lattice paths before minimum filtering',
               'aggregate_cartesian_product_paths':len(a[1])*len(b[1]),'checks':records})
    return {'pairs':len(records),'witness_and_all_six_rule_checks':'PASS','aggregate_cartesian_paths':len(a[1])*len(b[1])}


def analyze_pair(pair_id,x,y,cx=None,cy=None,save_witnesses=False):
    g=optimal_graph(x,y,cx,cy); b=bounds(g)
    results=[]
    for priorities in PRIORITIES:
        pp=profile(select_path(g,priorities))
        results.append({'priority':'>'.join(priorities),
                        'profile':[(tag,count) for tag,count in sorted(pp.items())],
                        'positive_labels':len(pp),'optional_positive_labels':sum(b[tag][0]==0 for tag in pp),
                        'variable_positive_counts':sum(b[tag][0]!=b[tag][1] for tag in pp),
                        'operations_with_optional_label':sum(count for tag,count in pp.items() if b[tag][0]==0)})
    out={'pair_id':pair_id,'reference':tuple(x),'test':tuple(y),'reference_categories':g['cx'],
         'test_categories':g['cy'],'distance':g['distance'],'optimal_paths_capped':g['paths_capped'],
         'bounds':[(tag,lo,hi) for tag,(lo,hi) in b.items()],
         'possible_labels':len(b),'mandatory_labels':sum(lo>0 for lo,hi in b.values()),
         'variable_labels':sum(lo!=hi for lo,hi in b.values()),
         'maximum_width':max([hi-lo for lo,hi in b.values()] or [0]),
         'total_width':sum(hi-lo for lo,hi in b.values()),'six_rules':results}
    if save_witnesses:
        out['witnesses']=[]
        for tag,(lo,hi) in b.items():
            if lo==hi:
                continue
            low,p_low=extremum(g,tag,witness=True)
            high,p_high=extremum(g,tag,True,True)
            out['witnesses'].append({'label':tag,'minimum':low,'maximum':high,
                                     'lower_path':path_json(g,p_low),'upper_path':path_json(g,p_high)})
    return out


def aggregate_pairs(pairs):
    per_rule={'>'.join(p):Counter() for p in PRIORITIES}
    for pair in pairs:
        for rule in pair['six_rules']:
            per_rule[rule['priority']].update({k:rule[k] for k in ('positive_labels','optional_positive_labels','variable_positive_counts','operations_with_optional_label')})
    for values in per_rule.values():
        values['optional_label_incidence_share']=values['optional_positive_labels']/values['positive_labels'] if values['positive_labels'] else 0
        values['optional_operation_share']=values['operations_with_optional_label']/sum(p['distance'] for p in pairs) if sum(p['distance'] for p in pairs) else 0
    return {'n':len(pairs),'ambiguous':sum(p['optimal_paths_capped']>1 for p in pairs),
            'variable_profile':sum(p['variable_labels']>0 for p in pairs),
            'possible_label_incidences':sum(p['possible_labels'] for p in pairs),
            'mandatory_label_incidences':sum(p['mandatory_labels'] for p in pairs),
            'variable_label_incidences':sum(p['variable_labels'] for p in pairs),
            'total_width':sum(p['total_width'] for p in pairs),
            'maximum_pair_width':max([p['maximum_width'] for p in pairs] or [0]),
            'pairs_with_any_optional_label':sum(p['mandatory_labels']<p['possible_labels'] for p in pairs),
            'distinct_reference_sequences':len({p['reference'] for p in pairs}),
            'distinct_test_sequences':len({p['test'] for p in pairs}),
            'total_distance':sum(p['distance'] for p in pairs),
            'six_rules':{key:dict(value) for key,value in per_rule.items()}}


def dominant_kind(script):
    counts=Counter(op.kind.value for op in script.operations)
    return max(KINDS,key=lambda k:(counts[k],-KINDS.index(k))) if counts else 'none'


def classify(selected):
    rows=[]; omitted=[]
    for rec in selected:
        for idx,mut in enumerate(rec['defects'],1):
            kind=expected_kind(mut['taxonomy']); pair_id=rec['id']+f'-D{idx}'
            if kind=='move':
                omitted.append({'pair_id':pair_id,'template':rec['template'],'taxonomy':mut['taxonomy']})
                continue
            x,y=rec['block_seq'],mut['block_seq']
            rows.append({'pair_id':pair_id,'template':rec['template'],'target_generator_kind':kind,
                         'block_dominant':dominant_kind(edit_script(x,y)),
                         'token_dominant':dominant_kind(edit_script(tokens(rec['st_code']),tokens(mut['st_code']))),
                         'length_rule':length_baseline(x,y),'constant_delete':'delete'})
    methods=('block_dominant','token_dominant','length_rule','constant_delete')
    assert len(rows)==174 and len(omitted)==14
    assert all(r[m] in KINDS for r in rows for m in methods)
    matrix={method:{truth:dict(Counter(r[method] for r in rows if r['target_generator_kind']==truth)) for truth in KINDS} for method in methods}
    per_class=[]
    for truth in KINDS:
        group=[r for r in rows if r['target_generator_kind']==truth]
        per_class.append({'target':truth,'n':len(group),**{m:sum(r[m]==truth for r in group) for m in methods}})
    paired=Counter((r['block_dominant']==r['target_generator_kind'],r['token_dominant']==r['target_generator_kind']) for r in rows)
    result={'task':'recovery of generator mutation mechanism, NOT engineering defect classification',
            'output':'exactly one of replace/delete/insert; greatest operation count in historical script; ties replace > delete > insert',
            'included':len(rows),'excluded_move_count':len(omitted),'excluded_moves':omitted,
            'target_counts':dict(Counter(r['target_generator_kind'] for r in rows)),
            'correct_counts':{m:sum(r[m]==r['target_generator_kind'] for r in rows) for m in methods},
            'per_class':per_class,'confusion_matrices':matrix,
            'paired_block_token':{'both_correct':paired[(True,True)],'block_only':paired[(True,False)],'token_only':paired[(False,True)],'neither':paired[(False,False)]},
            'constant_delete_note':'predeclared descriptive baseline, not trained or tuned',
            'interpretation':'The mutation name need not identify its exact shortest edit structure. This diagnostic compares recovery of the declared generator mechanism under the same single-output rule.'}
    write_csv('single_label_per_pair.csv',rows)
    write_json('single_label_comparison.json',result)
    return result


def dataset_analysis():
    selected=[json.loads(line) for line in (EXPERIMENTS/'public_working_subset.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
    cases=[]
    for rec in selected:
        for idx,mut in enumerate(rec['defects'],1):
            pair=analyze_pair(rec['id']+f'-D{idx}',rec['block_seq'],mut['block_seq'])
            pair.update(template=rec['template'],reference_id=rec['id'],taxonomy=mut['taxonomy'])
            cases.append(pair)
    synt=aggregate_pairs(cases)
    assert synt['n']==188 and synt['ambiguous']==34 and synt['variable_profile']==6
    original_intervals={p['pair_id']:p for p in map(json.loads,(EXPERIMENTS/'optimal_path_intervals.jsonl').read_text(encoding='utf-8').splitlines())}
    for case in cases:
        original=original_intervals[case['pair_id']]['bounds']
        assert case['distance']==original['distance']
        assert {tuple(tag):(lo,hi) for tag,lo,hi in case['bounds']}=={tuple(tag):tuple(values) for tag,values in original['category_bounds']}
    write_json('synthetic_all_paths.json',{'summary':synt,'pairs':cases})
    template_rows=[]
    for template in sorted({r['template'] for r in selected}):
        refs=[r for r in selected if r['template']==template]
        group=[p for p in cases if p['template']==template]
        ag=aggregate_pairs(group)
        template_rows.append({'template':template,'reference_records':len(refs),'unique_reference_sequences':len({tuple(r['block_seq']) for r in refs}),
                              'mutations':len(group),'unique_test_sequences':ag['distinct_test_sequences'],'ambiguous':ag['ambiguous'],
                              'variable_profile':ag['variable_profile'],'possible_labels':ag['possible_label_incidences'],
                              'mandatory_labels':ag['mandatory_label_incidences']})
    write_csv('synthetic_by_template.csv',template_rows)
    ext={}
    for file,tag in [('external_pilot_diagnostics.json','raw'),('external_pilot_normalized_diagnostics.json','normalized')]:
        payload=json.loads((EXPERIMENTS/file).read_text(encoding='utf-8'))
        items=[]; failures=[]
        for rec in payload['pairs']:
            if rec['pair_status']!='both_represented':
                failures.append(rec['pair_id']); continue
            p=analyze_pair(rec['pair_id'],rec['reference']['sequence'],rec['test']['sequence'])
            assert {tuple(t):(lo,hi) for t,lo,hi in p['bounds']}=={tuple(t):tuple(v) for t,v in rec['all_optimal_bounds']['category_bounds']}
            p.update(task=rec['task_id'],archive_group=rec['model'])
            items.append(p)
        totals=aggregate_pairs(items)
        totals.update(attempts=len(payload['pairs']),failures=failures,independent_tasks=len({p['task_id'] for p in payload['pairs']}))
        by_task=[]
        for task in sorted({p['task_id'] for p in payload['pairs']}):
            task_cases=[p for p in items if p['task']==task]
            by_task.append({'task':task,'attempts':sum(p['task_id']==task for p in payload['pairs']),
                            'represented':len(task_cases),'ambiguous':sum(p['optimal_paths_capped']>1 for p in task_cases),
                            'variable_profile':sum(p['variable_labels']>0 for p in task_cases),
                            'unique_reference_sequences':len({p['reference'] for p in task_cases}),
                            'unique_test_sequences':len({p['test'] for p in task_cases})})
        totals['by_task']=by_task
        ext[tag]=totals
        write_json(f'external_{tag}_all_paths.json',{'summary':totals,'pairs':items})
        write_csv(f'external_{tag}_by_task.csv',by_task)
    assert ext['raw']['ambiguous']==8 and ext['raw']['variable_profile']==7
    assert ext['normalized']['ambiguous']==9 and ext['normalized']['variable_profile']==8
    # Witness pedagogical examples and one fixed first variable real ST pair.
    examples=[analyze_pair('TEACH-PROFILE',('a','b'),('b','a'),('A','B'),('B','A'),True),
              analyze_pair('TEACH-POSITION',('a','a'),('a',),('A','A'),('A',),True),
              analyze_pair('TEACH-CONTEXT',('a','a'),('a',),('A','B'),('A',),True)]
    rawdata=json.loads((EXPERIMENTS/'external_pilot_diagnostics.json').read_text(encoding='utf-8'))
    variable_real=[p for p in rawdata['pairs'] if p['pair_status']=='both_represented' and any(lo!=hi for _,(lo,hi) in p['all_optimal_bounds']['category_bounds'])]
    real=min(variable_real,key=lambda p:(len(p['reference']['sequence'])+len(p['test']['sequence']),p['pair_id']))
    exemplar=analyze_pair(real['pair_id'],real['reference']['sequence'],real['test']['sequence'],save_witnesses=True)
    external_inputs={p['pair_id']:p for p in map(json.loads,(ROOT/'validation_protocol/external_pilot_pairs.jsonl').read_text(encoding='utf-8').splitlines())}
    actual=external_inputs[real['pair_id']]
    exemplar.update(task=real['task_id'],selection_rule='shortest total sequence length among raw external pairs with variable profile; pair_id breaks ties',
                    reference_source=actual['reference_source'],test_source=actual['test_source'],source_hashes=real['sources_sha256'])
    examples.append(exemplar)
    for ex in examples[:3]:
        g=optimal_graph(ex['reference'],ex['test'],ex['reference_categories'],ex['test_categories'])
        ex['six_paths']=[{'priority':'>'.join(pr),'path':path_json(g,select_path(g,pr))} for pr in PRIORITIES]
    write_json('witness_examples.json',examples)
    full,_=generate_records()
    selected_regen=select_working_subset(full)
    assert [r['id'] for r in selected]==[r['id'] for r in selected_regen]
    diversity={'full_generator':{'references':len(full),'templates':len({r['template'] for r in full}),
                 'unique_reference_sequences':len({tuple(r['block_seq']) for r in full}),
                 'unique_mutated_sequences':len({tuple(d['block_seq']) for r in full for d in r['defects']}),
                 'mutations':sum(len(r['defects']) for r in full)},
               'selected':{'references':len(selected),'templates':len({r['template'] for r in selected}),
                 'unique_reference_sequences':len({tuple(r['block_seq']) for r in selected}),
                 'unique_mutated_sequences':len({tuple(d['block_seq']) for r in selected for d in r['defects']}),
                 'template_sequence_strata':len({(r['template'],tuple(r['block_seq'])) for r in selected}),
                 'mutations':len(cases)},'by_template':template_rows,'external':ext,
               'sampling_note':'fixed purposive generator subset; 12 archived outputs grouped into 4 tasks, not 12 independent tasks; no inferential p-values'}
    write_json('diversity.json',diversity)
    return synt,ext,diversity,classify(selected),examples


def median_ms(fn,repeats=3):
    times=[]
    for _ in range(repeats):
        start=time.perf_counter(); fn(); times.append((time.perf_counter()-start)*1000)
    return statistics.median(times)


def performance():
    rows=[]
    for n in (16,32,64,128,256):
        source='PROGRAM PERF\nVAR\n x : BOOL;\n y : BOOL;\nEND_VAR\n'+'\n'.join('y := x;' for _ in range(n))+'\nEND_PROGRAM'
        extracted=tuple(canonize(source,strict=True))
        rep_ms=median_ms(lambda:canonize(source,strict=True))
        for requested_categories in (2,8,32):
            # Any n/2 reference occurrences can be deleted: a broad optimal
            # DAG and variable K, without enumerating binomially many paths.
            x=('a',)*n; y=('a',)*(n//2)
            cx=tuple(f'C{i%requested_categories}' for i in range(n))
            cy=tuple(f'C{i%requested_categories}' for i in range(n//2))
            f=distances(x,y); graph=optimal_graph(x,y,cx,cy,f)
            d_ms=median_ms(lambda:distances(x,y))
            graph_ms=median_ms(lambda:optimal_graph(x,y,cx,cy,f))
            bounds_ms=median_ms(lambda:bounds(graph))
            gc.collect(); tracemalloc.start()
            g_mem=optimal_graph(x,y,cx,cy); b_mem=bounds(g_mem)
            current,peak=tracemalloc.get_traced_memory(); tracemalloc.stop()
            rows.append({'m':len(x),'n':len(y),'requested_categories':requested_categories,'actual_label_count_K':len(graph['labels']),
                         'optimal_vertices':len(graph['edges']),'optimal_edges':sum(map(len,graph['edges'].values())),
                         'distance':graph['distance'],'representation_source_characters':len(source),
                         'representation_output_symbols':len(extracted),'representation_median_ms':rep_ms,
                         'forward_distance_median_ms':d_ms,'suffix_and_graph_median_ms':graph_ms,
                         'bounds_only_median_ms':bounds_ms,'total_core_median_stage_sum_ms':d_ms+graph_ms+bounds_ms,
                         'peak_traced_python_bytes':peak})
    info={'environment':{'python':sys.version,'implementation':platform.python_implementation(),'platform':platform.platform(),
                         'processor':platform.processor(),'timing_repeats':3,'timing_statistic':'median',
                         'memory':'peak Python allocations traced separately; not RSS; no timings taken with tracing'},
          'scope':'Synthetic bounded scaling probe, reference lengths 16..256, test lengths half as large. Representation uses m sequential assignments; alignment stress uses m and m/2 repeated equal symbols and fixed per-occurrence categories. All binomial(m,m/2) choices of deletions are optimal; counts are capped at two. These are separately specified probes, not measurements of end-to-end industrial ST compilation.',
          'rows':rows}
    write_json('performance.json',info); write_csv('performance.csv',rows)
    return info


def main():
    validation=validate()
    print('Oracle PASS',validation['pairs'],flush=True)
    synt,ext,diversity,classification,examples=dataset_analysis()
    print('Data analyses PASS',synt['ambiguous'],synt['variable_profile'],flush=True)
    perf=performance()
    result={'schema':'article4-review-computations/v1','date':'2026-11-09','oracle':validation,'synthetic':synt,
            'external':ext,'diversity':{'full':diversity['full_generator'],'selected':diversity['selected']},
            'single_label':classification,'performance_environment':perf['environment'],
            'real_witness_pair_id':examples[-1]['pair_id'],
            'limitations':['Synthetic and external ratios are fixed-set descriptive results, not estimated population frequencies.',
                           'No classification of behavioral defects or human diagnosis time is measured.',
                           'Only locally prepared outputs, not an externally published release or independent-party reproduction.',
                           'Benchmark memory is tracemalloc Python allocation peak, not OS resident memory.',
                           'Sequence and categories fixed; lexical/structural extraction quality is a separate question.']}
    write_json('review_computational_summary.json',result)
    manifest={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ('manifest.json','run_log.txt')}
    inputs=[EXPERIMENTS/'public_working_subset.jsonl',EXPERIMENTS/'optimal_path_intervals.jsonl',EXPERIMENTS/'external_pilot_diagnostics.json',
            EXPERIMENTS/'external_pilot_normalized_diagnostics.json',ROOT/'validation_protocol/external_pilot_pairs.jsonl']
    inputs += [EXPERIMENTS/'run_sensitivity.py'] + sorted((EXPERIMENTS/'vendor_source').glob('*.py'))
    write_json('manifest.json',{'outputs_sha256':manifest,'inputs_sha256':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in inputs}})
    print(json.dumps({'oracle':validation,'synthetic':synt,'classification':classification,'external':ext},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
